import ReactDOM from 'react-dom';
import React from 'react';
import App from './App.js';

ReactDOM.render(<App/>, document.getElementById('react-container'));