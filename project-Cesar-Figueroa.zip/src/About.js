import React from 'react'

const About = () => {
    return (
            <main>
                <div className="contact-container">
                    <div id="background-img-contact">
                    </div>
                    <div id="background-color-contact">
                    </div>
                    <div className="us-container">
                        <div className="us-container-unit">
                            <h1>Mision</h1>
                            <hr />
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur provident aspernatur excepturi itaque dolore quia unde quaerat laboriosam deleniti? Recusandae, modi aspernatur. Dignissimos tenetur maiores veniam ratione consequuntur asperiores perferendis!</p>
                            <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed ipsa quaerat, reiciendis laborum ullam doloremque ea laboriosam nostrum! Minus quae tempora beatae blanditiis autem quidem soluta, perspiciatis numquam rem! Nihil.</p>
                        </div>
                        <div className="us-container-unit">
                            <h1>Vision</h1>
                            <hr />
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi error debitis explicabo facere, dolore distinctio ipsam temporibus molestias tempora ex consectetur illum tempore fuga totam voluptatum nobis voluptas neque officia!</p>
                            <p >Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur provident aspernatur excepturi itaque dolore quia unde quaerat laboriosam deleniti? Recusandae, modi aspernatur. Dignissimos tenetur maiores veniam ratione consequuntur asperiores perferendis!</p>
                        </div>
                        <div className="us-container-unit">
                            <h1>Our trajectory</h1>
                            <hr />
                            <p >Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed ipsa quaerat, reiciendis laborum ullam doloremque ea laboriosam nostrum! Minus quae tempora beatae blanditiis autem quidem soluta, perspiciatis numquam rem! Nihil.</p>
                            <p > Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi error debitis explicabo facere, dolore distinctio ipsam temporibus molestias tempora ex consectetur illum tempore fuga totam voluptatum nobis voluptas neque officia!</p>
                        </div>
                    </div>
                </div>
            </main>
    )
}

export default About;