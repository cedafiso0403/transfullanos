import React from 'react';

const Products = () => {
    return (
            <main>
                <div className="products-container">
                    <div id="background-img-products">
                    </div>
                    <div id="background-color-products">
                    </div>
                    <div className="service-container">
                        <div className="service-container-unit">
                            <h2>Service 1</h2>
                        </div>
                        <div className="service-container-unit">
                            <h2>Service 2</h2>
                        </div>
                        <div className="service-container-unit">
                            <h2>Service 3</h2>
                        </div>
                        <div className="service-container-unit">
                            <h2>Service 4</h2>
                        </div>
                        <div className="service-container-unit">
                            <h2>Service 5</h2>
                        </div>
                        <div className="service-container-unit">
                            <h2>Service 6</h2>
                        </div>
                    </div>
                </div>
            </main>
    )
}

export default Products;